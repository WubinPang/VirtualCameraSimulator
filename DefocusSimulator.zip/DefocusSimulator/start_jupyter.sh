#!/bin/bash

# help infomation
usage="Usage: ./start_jupyter.sh [-s server_name] [-p server_port:local_port]"

# parse arguments: using getopts 
while getopts ":hs:p:" opt
do
  case "$opt" in 
  h)
    echo $usage
    exit 1
    ;;
  s)
    server_name=$OPTARG
    ;;
  p)
    server_port="$(cut -d':' -f1 <<< $"$OPTARG")"
    local_port="$(cut -d':' -f2 <<< $"$OPTARG")"
    ;;
  :)
    echo >&2 "[Error] Option -$OPTARG requires an argument"
    echo $usage
    exit 1
    ;;
  ?)
    echo >&2 "[Error] Invalid option: -$OPTARG"
    echo $usage
    exit 1
    ;;
  esac
done

# default arguments:
if [ "$server_name" = "" ]
then
  if [ "$HOSTNAME" = "dkserver1" ] || [ "$HOSTNAME" = "dkserver2" ] || [ "$HOSTNAME" = "dkmh" ]
  then
    server_name="local"
  else
    server_name="dkserver2"
  fi
fi
if [ "$server_port" = "" ]
then
  server_port=8889
fi
if [ "$local_port" = "" ]
then
  local_port=8080
fi

# show parameters
echo "Starting jupyter on $server_name, from server port $server_port to local port $local_port"

# if running on the server
if [ $HOSTNAME = $server_name ] || [ $server_name = "local" ]
then
  echo "Local machine as server, opening jupyter notebook..."
  # check port usage
  if [ "$(netstat -n -a | grep 127.0.0.1:$server_port)" != "" ]
  then
    echo >&2 "[Error] Server port $server_port is occupied"
    exit 1
  fi
  # open tmux session
  sessname="jpnb$server_port"
  if [[ "$(tmux ls)" =~ $sessname ]]
  then
    echo >&2 "[Error] tmux session $sessname exists"
    exit 1
  fi
  tmux new -d -s $sessname
  # launch jupyter notebook
  tmux send -t $sessname "source activate mh" ENTER
  tmux send -t $sessname "jupyter-notebook --no-browser --port=$server_port --notebook-dir='~/Desktop/depth2defocus'" ENTER
  echo "Jupyter notebook server launched"
  echo "Please open http://localhost:$server_port in browser"
  exit 0

# if running on clinent
else
  # check port usage
  if [ "$(netstat -n -a | grep 127.0.0.1:$local_port)" != "" ]
  then
    echo >&2 "[Error] Local port $local_port is occupied"
    exit 1
  fi
  # start remote jupyter notebook server
  echo "Opening jupyter on server..."
  remote_cmd="/home/minghao/Desktop/depth2defocus/start_jupyter.sh $@ 2>&1"
  remote_respond="$(ssh $server_name $remote_cmd)"
  # check remote respond
  if [[ $remote_respond =~ "Error" ]]
  then
    echo >&2 "Error when opening jupyter notebook on server"
    echo "Please check following error messate and try again"
    echo $remote_respond
    exit 1
  fi
  echo "Jupyter notebook server running on port $server_port on server"
  # establish ssh port forward
  echo "Establishing ssh port forward through port $local_port"
  echo "If success, open http://localhost:$local_port in browser"
  ssh -L $local_port:localhost:$server_port $server_name
fi
